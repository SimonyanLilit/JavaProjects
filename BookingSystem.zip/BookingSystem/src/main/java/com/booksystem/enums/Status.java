package com.booksystem.enums;

public enum Status {
    ACTIVE, INACTIVE,
}

package com.booksystem.enums;

public enum Role {
    USER, ADMIN, CUSTOMER
}

package com.booksystem.exceptions;

public interface ErrorMessages {
    String USER_NOT_FOUND_WITH_EMAIL="user not found";
}

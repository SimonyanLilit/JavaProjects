package com.booksystem.exceptions.userexceptions;

import com.booksystem.exceptions.ResourceAlreadyExistsException;

public class UserAlreadyExistsException extends ResourceAlreadyExistsException {

    public UserAlreadyExistsException(String message) {
        super(message);
    }
}

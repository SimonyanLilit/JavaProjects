package com.booksystem.exceptions.restaurantexceptions;

import com.booksystem.exceptions.BookingValidationException;

public class RestaurantValidationException extends BookingValidationException {
    public RestaurantValidationException(String message) {
        super(message);
    }
}

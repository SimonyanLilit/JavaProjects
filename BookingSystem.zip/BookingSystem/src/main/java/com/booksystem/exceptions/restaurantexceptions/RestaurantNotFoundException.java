package com.booksystem.exceptions.restaurantexceptions;

import com.booksystem.exceptions.BookingNotFoundException;

public class RestaurantNotFoundException extends BookingNotFoundException {
    public RestaurantNotFoundException(String message) {
        super(message);
    }
}

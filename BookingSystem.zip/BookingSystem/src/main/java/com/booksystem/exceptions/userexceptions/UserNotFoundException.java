package com.booksystem.exceptions.userexceptions;

import com.booksystem.exceptions.BookingNotFoundException;

public class UserNotFoundException extends BookingNotFoundException {
    public UserNotFoundException(String message) {
        super(message);
    }
}

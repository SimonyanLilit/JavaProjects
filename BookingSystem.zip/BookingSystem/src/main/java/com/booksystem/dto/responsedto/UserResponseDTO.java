package com.booksystem.dto.responsedto;

import com.booksystem.enums.Role;
import com.booksystem.enums.Status;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonPropertyOrder
public class UserResponseDTO {
    @JsonIgnore()
    private Integer id;
    @JsonProperty("name")
    private  String name;
    @JsonProperty("surname")
    private  String surname;
    @JsonIgnore()
    private  Integer year;
    @JsonProperty("email")
    private  String email;
    @JsonIgnore()
    private  String password;
    @JsonIgnore()
    private  String verifyCode;
    @JsonIgnore()
    private Status status;
    @JsonIgnore()
    private Role role;
    @JsonIgnore()
    private  String resetToken;
}

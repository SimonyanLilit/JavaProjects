package com.booksystem.service;

import com.booksystem.dto.requestdto.RestaurantRequestDTO;
import com.booksystem.dto.responsedto.RestaurantResponseDTO;
import com.booksystem.exceptions.APIException;
import com.booksystem.model.RestaurantEntity;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

public interface RestaurantService {
    RestaurantEntity add (RestaurantRequestDTO dto, String email) throws APIException;
    List<RestaurantResponseDTO> getAll(String name) throws APIException;
    List<RestaurantResponseDTO> getByAddress(String address) throws APIException;
    RestaurantEntity update(RestaurantRequestDTO dto) throws APIException;
    RestaurantResponseDTO reserve(Integer id,Integer tablesCount) throws APIException;
    List<RestaurantEntity> search(String name);
}

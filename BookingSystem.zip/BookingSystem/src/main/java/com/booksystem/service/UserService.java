package com.booksystem.service;

import com.booksystem.dto.requestdto.UserRequestDTO;
import com.booksystem.exceptions.APIException;
import com.booksystem.model.UserEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;


public interface UserService {
    UserEntity save(UserRequestDTO dto) throws APIException;
    UserEntity saveAdmin(UserRequestDTO dto)throws APIException;
    List<UserEntity> getBYUsername(String email);
    UserEntity verifyUser(String email, String code)throws APIException;
    UserEntity changePassword(String oldPassword, String newPassword, String confirmPassword, String email) throws APIException;
    void deleteUser(Integer id) throws APIException;
    UserEntity resetToken(String email) throws APIException;
     Boolean verifyResetToken( String email,  String resetToken) throws APIException;
     void forgotPassword(String email, String newPassword, String confirmPassword) throws APIException;
     UserEntity update(UserRequestDTO dto) throws APIException;
}

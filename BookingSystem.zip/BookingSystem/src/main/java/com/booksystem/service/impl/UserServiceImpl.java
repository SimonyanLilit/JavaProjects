package com.booksystem.service.impl;

import com.booksystem.dto.requestdto.UserRequestDTO;
import com.booksystem.enums.Role;
import com.booksystem.enums.Status;
import com.booksystem.exceptions.APIException;
import com.booksystem.exceptions.userexceptions.UserAlreadyExistsException;
import com.booksystem.exceptions.userexceptions.UserNotFoundException;
import com.booksystem.exceptions.userexceptions.UserValidationException;
import com.booksystem.model.UserEntity;
import com.booksystem.repository.UserRepository;
import com.booksystem.service.UserService;
import com.booksystem.util.BookingMailSender;
import com.booksystem.util.TokenGenerate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private BookingMailSender mailSender;

@Autowired
private PasswordEncoder passwordEncoder;
    @Override
    public UserEntity save(UserRequestDTO dto) throws APIException {
        validateDuplicates(dto);
        validateFields(dto);
        validatePassword(dto.getRequestPassword());
        String verifyCode = TokenGenerate.generateVerifyCode();
        UserEntity userEntity=new UserEntity();
        userEntity.setId(0);
        userEntity.setName(dto.getRequestName());
        userEntity.setSurname(dto.getRequestSurname());
        userEntity.setYear(dto.getRequestYear());
        userEntity.setPassword(passwordEncoder.encode(dto.getRequestPassword()));
        userEntity.setVerifyCode(verifyCode);
        userEntity.setStatus(Status.INACTIVE);
        userEntity.setEmail(dto.getRequestEmail());
        userEntity.setRole(dto.getRequestRole());
        try {
            userRepository.save(userEntity);
        }catch (Exception e){
            throw new APIException("problem during saving user");

        }
mailSender.sendEmail(dto.getRequestEmail(), "your verify code", "your verify code"+verifyCode);
return userEntity;
    }



    @Override
    public UserEntity saveAdmin(UserRequestDTO dto) throws APIException {
        validateDuplicates(dto);
        validateFields(dto);
        validatePassword(dto.getRequestPassword());
        UserEntity userEntity=new UserEntity();
        userEntity.setId(0);
        userEntity.setName(dto.getRequestName());
        userEntity.setSurname(dto.getRequestSurname());
        userEntity.setYear(dto.getRequestYear());
        userEntity.setPassword(dto.getRequestPassword());
        userEntity.setStatus(Status.ACTIVE);
        userEntity.setEmail(dto.getRequestEmail());
        userEntity.setRole(Role.ADMIN);
        try {
            userRepository.save(userEntity);
        }catch (Exception e){
            throw new APIException("problem during saving user");

        }

        return userEntity;
    }

    @Override
    public List<UserEntity> getBYUsername(String email) {
        List<UserEntity> userEntityList = userRepository.getByEmail(email);
        if(userEntityList.isEmpty()){
            throw new UserNotFoundException("user not found");
        }

        return userEntityList;
    }

    @Override
    public UserEntity verifyUser(String email, String code) throws APIException {
        UserEntity userEntity=null;
        try {
            List<UserEntity> entityList = userRepository.getByEmail(email);
            userEntity=entityList.get(0);
        }catch (Exception e){
            throw new UserNotFoundException("wrong email");
        }
        String verifyCode = userEntity.getVerifyCode();
        if (!verifyCode.equals(code)){
            throw new UserValidationException("wrong verify code") ;
        }
        userEntity.setStatus(Status.ACTIVE);
        userEntity.setVerifyCode(null);
        try {
            userRepository.save(userEntity);
        }catch (Exception e){
            throw  new APIException("problem during updating user");
        }
        return userEntity;
    }

    @Override
    public UserEntity changePassword(String oldPassword, String newPassword, String confirmPassword, String email) throws APIException {
        UserEntity userEntity=null;
        validatePassword(newPassword);
        if (!newPassword.equals(confirmPassword)){
            throw new UserValidationException("Passwords don't match");
        }try {
            List<UserEntity> entityList = userRepository.getByEmail(email);
            userEntity = entityList.get(0);
        }catch (Exception e){
            throw new APIException("problem with getting user");
        }
        if(!passwordEncoder.encode(oldPassword).equals(userEntity.getPassword())){
            throw new UserValidationException("wrong old password");
        }
        userEntity.setPassword(passwordEncoder.encode(newPassword));
        try{
            userRepository.save(userEntity);
        }catch (Exception e){
            throw new APIException("problem during updating user");
        }
        return userEntity;
    }

    @Override
    public void deleteUser(Integer id) throws APIException {
        Optional<UserEntity> userEntity=null;
        try {

             userEntity = userRepository.findById(id);
             if (userEntity.isEmpty())
                 throw new APIException("user not found with iven id");
             userRepository.deleteById(id);
        }catch (Exception e){
            throw new APIException("problem during deleting user");
        }

    }

    @Override
    public UserEntity resetToken(String email) throws APIException {
        UserEntity userEntity=null;
        List<UserEntity> userEntityList;
      try {
          userEntityList = userRepository.getByEmail(email);
          if(userEntityList.isEmpty())
              throw new UserNotFoundException("wrong email "+email);

          userEntity = userEntityList.get(0);
          String resetToken = TokenGenerate.generateResetToken();
          userEntity.setResetToken(resetToken);
          userRepository.save(userEntity);
          mailSender.sendEmail(email,"your password change token",resetToken);
      }catch (Exception e){
          throw new APIException("problem during sending email");
      }
      return userEntity;
        }

    @Override
    public Boolean verifyResetToken(String email, String resetToken) throws APIException {
        try {
            UserEntity userEntity = userRepository.getByEmailAndResetToken(email, resetToken);
            if (userEntity==null){
                throw new UserValidationException("Wrong reset token");
            }
        }catch (Exception e){
            throw new APIException("problem during verifying");
        }
      return true;
    }

    @Override
    public void forgotPassword(String email, String newPassword, String confirmPassword) throws APIException {


        if (!newPassword.equals(confirmPassword)){
            throw new UserValidationException("passwords don't match");
        }
        validatePassword(newPassword);
       try {
          userRepository.update(email,passwordEncoder.encode(newPassword));
       }catch (Exception e){
           throw new APIException("problem during updating password");
       }

    }

    @Override
    public UserEntity update(UserRequestDTO dto) throws APIException {
        validateDuplicates(dto);
        Optional<UserEntity> optionalUser = userRepository.findById(dto.getId());
        if (optionalUser.isEmpty())
            throw new UserNotFoundException("user not found with given id");
        UserEntity userEntity = optionalUser.get();
        userEntity.setName(dto.getRequestName()==null? userEntity.getName() : dto.getRequestName());
        userEntity.setSurname(dto.getRequestSurname()==null? userEntity.getSurname() : dto.getRequestSurname());
        userEntity.setYear(dto.getRequestYear()==null? userEntity.getYear() : dto.getRequestYear());
        userEntity.setEmail( dto.getRequestEmail());
        try {
            userRepository.save(userEntity);
        }catch (Exception e){
            throw new APIException("problem during updating password");
        }
        return userEntity;
    }
    public void validateDuplicates(UserRequestDTO dto){
        Optional<UserEntity> userEntity=null;
        //post
        if (dto.getId()==null){
             userEntity = userRepository.findByEmail(dto.getRequestEmail());
            if (userEntity.isPresent())
                throw new UserAlreadyExistsException("user already exists");
        }
        //put
            else{
           userEntity = userRepository.findByEmailAndIdNot(dto.getRequestEmail(), dto.getId());
           if (userEntity.isPresent())
               throw new UserAlreadyExistsException("user already exists");
        }
    }


    public void validateFields(UserRequestDTO dto){
        if(dto.getRequestName()==null||dto.getRequestName().isBlank()){
            throw new UserValidationException("user's name can't be empty");
        }
        if(dto.getRequestSurname()==null||dto.getRequestSurname().isBlank()){
            throw new UserValidationException("user's surname can't be empty");
        }
        if(dto.getRequestYear()<1910 || dto.getRequestYear()>2020){
            throw new UserValidationException("user's birth year should be between 1910 and 2020");
        }

    }
     private void validatePassword(String requestPassword){

        int countOfDigit=0;
        int countOfUpperCase=0;
        if(requestPassword.length()<6){
            throw new UserValidationException("Password is short");
        }
         for (int i = 0; i < requestPassword.length(); i++) {
             char c = requestPassword.charAt(i);
             if(Character.isDigit(c))
                 countOfDigit++;
             else
             if (Character.isUpperCase(c))
                 countOfUpperCase++;

         }
         if(countOfDigit<2)
             throw  new UserValidationException("password should contain at least 2 digits");
         if(countOfUpperCase<1)
             throw  new UserValidationException("password should contain at least 1 upper case");
    }
}

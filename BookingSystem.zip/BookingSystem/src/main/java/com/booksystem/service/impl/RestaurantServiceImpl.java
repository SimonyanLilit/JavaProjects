package com.booksystem.service.impl;

import com.booksystem.dto.requestdto.RestaurantRequestDTO;
import com.booksystem.dto.responsedto.RestaurantResponseDTO;
import com.booksystem.enums.Role;
import com.booksystem.exceptions.APIException;
import com.booksystem.exceptions.restaurantexceptions.RestaurantNotFoundException;
import com.booksystem.exceptions.restaurantexceptions.RestaurantValidationException;
import com.booksystem.exceptions.userexceptions.UserValidationException;
import com.booksystem.model.RestaurantEntity;
import com.booksystem.model.UserEntity;
import com.booksystem.repository.RestaurantRepository;
import com.booksystem.repository.UserRepository;
import com.booksystem.service.RestaurantService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RestaurantServiceImpl implements RestaurantService {
    @Autowired
    private RestaurantRepository restaurantRepository;
    @Autowired
    private UserRepository userRepository;
    @Override
    public RestaurantEntity add(RestaurantRequestDTO dto, String email) throws APIException {
        List<UserEntity> userEntityList = userRepository.getByEmail(email);
        UserEntity userEntity = userEntityList.get(0);
        if (!userEntity.getRole().equals(Role.CUSTOMER))
            throw new UserValidationException("you have no permission to add restaurant");
        RestaurantEntity restaurant=new RestaurantEntity();
        restaurant.setId(0);
        restaurant.setName(dto.getName());
        restaurant.setAddress(dto.getAddress());
        restaurant.setPhone(dto.getPhone());
        restaurant.setTables(dto.getTables());
        restaurant.setUserEntity(userEntity);
        try {
            RestaurantEntity restaurantEntity = restaurantRepository.save(restaurant);

        }catch (Exception e){
            throw new APIException("problem during adding restaurant");
        }
return restaurant;
    }

    @Override
    public List<RestaurantResponseDTO> getAll(String name) throws APIException {
        List<RestaurantEntity> restaurantEntities=null;
        try {
            if (name==null) {
                restaurantEntities = restaurantRepository.getAllBy();
            }
            else
                restaurantEntities=restaurantRepository.getByName(name);

        }catch (Exception e){
            throw new APIException("problem during getting restaurants");
        }
        ObjectMapper objectMapper= new ObjectMapper();
        List<RestaurantResponseDTO> restaurantResponseDTOS=objectMapper.
                convertValue(restaurantEntities,new TypeReference<List<RestaurantResponseDTO>>(){});
        return restaurantResponseDTOS;
    }

    @Override
    public List<RestaurantResponseDTO> getByAddress(String address) throws APIException {
        List<RestaurantEntity> entityList=null;
        try {
            entityList=restaurantRepository.getByAddress(address);

        }catch (Exception e){
            throw new APIException("problem during getting restaurants");
        }
        if (entityList.isEmpty())
            throw new RestaurantNotFoundException("wrong address");
       return new ObjectMapper().convertValue(entityList,new TypeReference<List<RestaurantResponseDTO>>(){});
    }

    @Override
    public RestaurantEntity update(RestaurantRequestDTO dto) throws APIException {
        RestaurantEntity restaurantEntity=null;
        try {
           restaurantEntity=restaurantRepository.getById(dto.getId());
        }catch (Exception e){
            throw new APIException("problem during updating restaurant");
        }
        restaurantEntity.setName(dto.getName()==null? restaurantEntity.getName() : dto.getName());
        restaurantEntity.setAddress(dto.getAddress()==null? restaurantEntity.getAddress() : dto.getAddress());
        restaurantEntity.setPhone(dto.getPhone()==null? restaurantEntity.getPhone() : dto.getPhone());
        restaurantEntity.setTables(dto.getTables()==null? restaurantEntity.getTables() : dto.getTables());
        try {
            restaurantRepository.save(restaurantEntity);
        }catch (Exception e){
            throw new APIException("problem during updating restaurant");
        }
      return restaurantEntity;
    }

    @Override
    public RestaurantResponseDTO reserve(Integer id, Integer tablesCount) throws APIException {
        RestaurantEntity restaurantEntity = restaurantRepository.findById(id).get();
        restaurantEntity.setReservedTables(restaurantEntity.getReservedTables()==null?0:restaurantEntity.getReservedTables());
       if (restaurantEntity.getTables()-restaurantEntity.getReservedTables()<tablesCount)
           throw  new RestaurantValidationException("you can't reserve more tables then are available at the moment");
       restaurantEntity.setReservedTables(restaurantEntity.getReservedTables()+tablesCount);
       try {
           restaurantRepository.save(restaurantEntity);
       }catch (Exception e){
           throw new APIException("problem during updating restaurant");
       }
       return new ObjectMapper().convertValue(restaurantEntity,RestaurantResponseDTO.class);

    }

    @Override
    public List<RestaurantEntity> search(String name) {
        return restaurantRepository.search(name);
    }

}

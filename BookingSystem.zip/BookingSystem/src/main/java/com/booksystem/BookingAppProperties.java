package com.booksystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookingAppProperties {
    public static void main(String[] args) {
        SpringApplication.run(BookingAppProperties.class);
    }
}

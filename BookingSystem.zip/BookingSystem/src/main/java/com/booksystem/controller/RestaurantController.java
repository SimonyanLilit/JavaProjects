package com.booksystem.controller;

import com.booksystem.dto.requestdto.RestaurantRequestDTO;
import com.booksystem.dto.responsedto.RestaurantResponseDTO;
import com.booksystem.exceptions.APIException;
import com.booksystem.model.RestaurantEntity;
import com.booksystem.service.RestaurantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@RestController
@RequestMapping("/restaurant")
public class RestaurantController {
    @Autowired
    private RestaurantService restaurantService;
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public RestaurantEntity addRestaurant(@RequestBody RestaurantRequestDTO dto, Principal principal) throws APIException {
        String name = principal.getName();
        return restaurantService.add(dto,name);

    }
    @GetMapping("/get-all")
    public List<RestaurantResponseDTO> getAll(@RequestParam(required = false)String name) throws APIException {
return restaurantService.getAll(name);
    }
    @GetMapping("/get-by-address")
    public List<RestaurantResponseDTO> getByAddress(@RequestParam String address) throws APIException {
        return restaurantService.getByAddress(address);

    }
    @PutMapping("/update")
    public RestaurantEntity update(@RequestBody RestaurantRequestDTO dto) throws APIException {
      return restaurantService.update(dto);
    }
    @PatchMapping("/reserve/{id}")
    public  RestaurantResponseDTO reserve(@PathVariable Integer id,@RequestParam Integer tablesCount) throws APIException {
        return restaurantService.reserve(id,tablesCount);
    }
    @GetMapping("/search")
    public List<RestaurantEntity> search(@RequestParam String name){
        return restaurantService.search(name);

    }
}
